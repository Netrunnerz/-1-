var container;
var camera, scene, renderer;

var N = 255;

var imagedata;

init();
animate();


function init()
{
    container = document.getElementById("container");
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1 , 4000);
    camera.position.set(N/2, N/2, N*1.5);
    camera.lookAt(new THREE.Vector3(N/2,0,N/2));
    renderer = new THREE.WebGLRenderer({antialias: false});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0xfffccc, 1);
    container.appendChild(renderer.domElement);
    window.addEventListener("resize", onWindowResize, false);

    var spotLight = new THREE.PointLight(0xffffff);
    spotLight.position.set(N,N,N/2);
    scene.add(spotLight);

    var canvas = document.createElement("canvas");
    var context = canvas.getContext("2d");
    var img = new Image();

    img.onload = function()
    {
        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img , 0, 0);
        imagedata = context.getImageData(0,0,img.width,img.height);
        addTerrain();
    }
    img.src = "pics/plateau.jpg";
    
}

function getPixel(imagedata, x, y)
{
    var position = ( x + imagedata.width * y ) * 4, data = imagedata.data;
    return data[ position ];
}

function onWindowResize()
{
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate()
{
    requestAnimationFrame(animate);
    render();
}

function render()
{
    renderer.render(scene, camera);
}

function addTerrain()
{
    var geometry = new THREE.Geometry();

    for(var i = 0; i < N; i++)
    for(var j = 0; j < N; j++)
    {
        var y = getPixel(imagedata, i, j);
        geometry.vertices.push(new THREE.Vector3( i, y/6, j ));
    }

    
    for(var i = 0; i < N-1; i++)
    for(var j = 0; j < N-1; j++)
    {
        geometry.faces.push(new THREE.Face3(i + j *N, (i+1) + j *N, (i+1) + (j+1) *N));
        geometry.faces.push(new THREE.Face3(i + j *N, (i+1) + (j+1) *N, i + (j+1) *N));

        geometry.faceVertexUvs[0].push([new THREE.Vector2(i/N, j/N),
            new THREE.Vector2(i/N, (j+1)/N),
            new THREE.Vector2((i+1)/N, (j+1)/N)]);
    
        geometry.faceVertexUvs[0].push([new THREE.Vector2(i/N, j/N),
            new THREE.Vector2((i+1)/N, (j+1)/N),
            new THREE.Vector2((i+1)/N, j/N)]);
    }

    geometry.computeFaceNormals();
    geometry.computeVertexNormals();

    var loader = new THREE.TextureLoader();
    var tex = loader.load("pics/landtile.jpg");

    var triangleMaterial = new THREE.MeshLambertMaterial({
            map: tex,
            wireframe: false,
            side: THREE.DoubleSide
    });
    
    var triangleMesh = new THREE.Mesh(geometry, triangleMaterial);
    triangleMesh.position.set(0.0, 0.0, 0.0);
    
    scene.add(triangleMesh);
    
}



