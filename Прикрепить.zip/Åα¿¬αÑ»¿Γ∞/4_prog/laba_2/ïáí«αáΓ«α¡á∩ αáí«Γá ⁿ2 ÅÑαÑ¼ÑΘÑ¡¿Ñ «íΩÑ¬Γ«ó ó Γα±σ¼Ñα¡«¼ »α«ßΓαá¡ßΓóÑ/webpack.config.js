const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
  entry: './main.js', // Путь к вашему главному файлу JS
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js'
  },
  module: {
    rules: [
      {
        test: /\.(png|jpg|gif)$/i,
        type: 'asset/resource'
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './index.html' // Путь к вашему HTML шаблону
    }),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: './planets', // Путь к вашим текстурам
          to: 'planets' // Путь, куда текстуры будут скопированы в папке dist
        }
      ]
    })
  ],
};
