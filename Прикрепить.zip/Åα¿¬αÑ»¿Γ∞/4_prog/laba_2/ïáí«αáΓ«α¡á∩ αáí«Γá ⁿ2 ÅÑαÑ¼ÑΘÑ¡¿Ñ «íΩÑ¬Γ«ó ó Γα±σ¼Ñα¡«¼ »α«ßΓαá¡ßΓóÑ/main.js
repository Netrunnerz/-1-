import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// Инициализация сцены, камеры и рендерера
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 10000);
camera.position.z = 50;
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Настройка контроллера для камеры
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.enablePan = false;
controls.enableZoom = true;

// Загрузчик текстур
const textureLoader = new THREE.TextureLoader();

// Создание солнца
const sunGeometry = new THREE.SphereGeometry(5, 32, 32);
const sunMaterial = new THREE.MeshBasicMaterial({
  map: textureLoader.load('planets/sunmap.jpg'),
});
const sunMesh = new THREE.Mesh(sunGeometry, sunMaterial);
scene.add(sunMesh);

// Создание звездного фона
const galaxyGeometry = new THREE.SphereGeometry(1000, 64, 64);
const galaxyMaterial = new THREE.MeshBasicMaterial({
  side: THREE.BackSide,
  map: textureLoader.load('planets/starmap.jpg')
});
const galaxyMesh = new THREE.Mesh(galaxyGeometry, galaxyMaterial);
scene.add(galaxyMesh);

// Свет от солнца
const sunlight = new THREE.PointLight(0xffffff, 1.5, 2000);
sunlight.position.set(0, 0, 0);
scene.add(sunlight);

// Создание планет
const planets = {};
function createPlanet(name, options) {
  const { texture, bumpMap, cloudMap, size, orbitDistance, orbitSpeed, rotationSpeed } = options;
  const planetGeometry = new THREE.SphereGeometry(size, 32, 32);
  const planetMaterial = new THREE.MeshPhongMaterial({
    map: textureLoader.load(texture),
    bumpMap: bumpMap ? textureLoader.load(bumpMap) : null,
    bumpScale: 0.005
  });
  const planetMesh = new THREE.Mesh(planetGeometry, planetMaterial);
  // Планета будет вращаться вокруг солнца, поэтому пока не задаем ей позицию
  scene.add(planetMesh);

  if (cloudMap) {
    const cloudGeometry = new THREE.SphereGeometry(size + 0.03, 32, 32);
    const cloudMaterial = new THREE.MeshPhongMaterial({
      map: textureLoader.load(cloudMap),
      transparent: true,
    });
    const cloudMesh = new THREE.Mesh(cloudGeometry, cloudMaterial);
    planetMesh.add(cloudMesh);
  }

  // Добавляем данные для вращения и орбиты
  planetMesh.userData = {
    orbitSpeed,
    rotationSpeed,
    orbitDistance,
    angle: Math.random() * Math.PI * 2 // Случайная начальная позиция на орбите
  };

  planets[name] = planetMesh;
}

// Планеты
createPlanet('mercury', {
    texture: 'planets/mercury/mercurymap.jpg',
    bumpMap: 'planets/mercury/mercurybump.jpg',
    size: 0.38,
    orbitDistance: 5.79,
    orbitSpeed: 0.024,
    rotationSpeed: 0.0017
});

createPlanet('venus', {
    texture: 'planets/venus/venusmap.jpg',
    bumpMap: 'planets/venus/venusbump.jpg',
    size: 0.95,
    orbitDistance: 10.82,
    orbitSpeed: 0.013,
    rotationSpeed: -0.00025 
});

createPlanet('earth', {
    texture: 'planets/earth/earthmap1k.jpg',
    bumpMap: 'planets/earth/earthbump1k.jpg',
    cloudMap: 'planets/earth/earthcloudmap.jpg',
    size: 1,
    orbitDistance: 15,
    orbitSpeed: 0.01,
    rotationSpeed: 0.005
});

createPlanet('mars', {
    texture: 'planets/mars/marsmap1k.jpg',
    bumpMap: 'planets/mars/marsbump1k.jpg',
    size: 0.6,
    orbitDistance: 22.79,
    orbitSpeed: 0.008,
    rotationSpeed: 0.005
});
  
// Параметры для Луны
createPlanet('moon', {
    texture: 'planets/earth/moon/moonmap1k.jpg',
    bumpMap: 'planets/earth/moon/moonbump1k.jpg',
    size: 0.3, // Примерный размер, Земля = 1
    orbitDistance: 2, // Примерное расстояние от Земли до Луны в астрономических единицах, умноженное на масштабный фактор
    orbitSpeed: 0.01, // Примерная скорость орбитального движения, нужно установить реалистичное значение
    rotationSpeed: 0.002 // Примерная скорость вращения, нужно установить реалистичное значение
});

// Добавляем Луну как спутник Земли
planets.moon.orbitCenter = planets.earth; // Устанавливаем Землю как центр орбиты для Луны


let isAnimating = false;
let currentFocus = null;
let baseDistance = 50;

function focusOnPlanet(planet) {
    if (isAnimating) return; // Если уже происходит анимация, выходим
    isAnimating = true; // Устанавливаем флаг анимации
    currentFocus = planet;

    const targetPosition = { x: planet.position.x + 10, y: planet.position.y + 10, z: planet.position.z + 10 };
    const startPosition = { x: camera.position.x, y: camera.position.y, z: camera.position.z };
    const targetControl = new THREE.Vector3().copy(planet.position);
    
    const duration = 1000; // Продолжительность анимации в мс
    const startTime = performance.now();
  
    function animateCamera(time) {
      const elapsedTime = time - startTime;
      const fraction = elapsedTime / duration;
  
      if (fraction < 1) {
        // Интерполяция позиции камеры
        camera.position.x = startPosition.x + (targetPosition.x - startPosition.x) * fraction;
        camera.position.y = startPosition.y + (targetPosition.y - startPosition.y) * fraction;
        camera.position.z = startPosition.z + (targetPosition.z - startPosition.z) * fraction;
        controls.target.lerp(targetControl, fraction); // Плавное изменение цели камеры
        controls.update();
        requestAnimationFrame(animateCamera);
      } else {
        // Конец анимации
        camera.position.set(targetPosition.x, targetPosition.y, targetPosition.z);
        controls.target.copy(targetControl);
        controls.update();
        isAnimating = false; // Сброс флага анимации
        baseDistance = camera.position.distanceTo(planet.position);
         
      }
    }
  
    requestAnimationFrame(animateCamera);
}


document.addEventListener('wheel', (event) => {
    if (currentFocus) {
        baseDistance += event.deltaY * 0.05; // Изменяем расстояние в зависимости от направления прокрутки
        baseDistance = Math.max(3, baseDistance); // Устанавливаем минимальное расстояние, чтобы камера не приближалась слишком близко
    }
});

document.addEventListener('keydown', (event) => {
    switch (event.key) {
        case '1':
            focusOnPlanet(planets.mercury);
            break;
        case '2':
            focusOnPlanet(planets.venus);
            break;
        case '3':
            focusOnPlanet(planets.earth);
            break;
        case '4':
            focusOnPlanet(planets.mars);
        case '5':
            focusOnPlanet(planets.moon);
            break;
        case '0':
            focusOnPlanet(sunMesh);
            break;
        case 'Escape': // Сброс фокуса и возврат к обзору солнечной системы
            currentFocus = null;
            controls.target.set(0, 0, 0); // Центр солнечной системы
            camera.position.set(0, 0, 50); // Возврат к начальному положению камеры
            controls.update();
            break;
    }
});



// Функция анимации
function animate() {
    requestAnimationFrame(animate);
    
    // Вращение планет вокруг Солнца и вокруг своих осей
    Object.values(planets).forEach(planet => {
      // Проверяем, заданы ли данные для вращения и орбиты
      if (planet.userData.orbitSpeed !== undefined) {
        planet.userData.angle += planet.userData.orbitSpeed;
        // Обновляем положение планеты в зависимости от угла и расстояния орбиты
        planet.position.x = Math.cos(planet.userData.angle) * planet.userData.orbitDistance;
        planet.position.z = Math.sin(planet.userData.angle) * planet.userData.orbitDistance;
      }
  
      if (planet.userData.rotationSpeed !== undefined) {
        planet.rotation.y += planet.userData.rotationSpeed;
      }
    });
  
    // Особая логика для Луны, которая должна вращаться вокруг Земли
    if (planets.moon) {
      const moon = planets.moon;
      const earth = planets.earth;
      moon.userData.angle += moon.userData.orbitSpeed;
  
      // Для расчета положения Луны используем угол и расстояние от Земли
      moon.position.x = earth.position.x + Math.cos(moon.userData.angle) * moon.userData.orbitDistance;
      moon.position.z = earth.position.z + Math.sin(moon.userData.angle) * moon.userData.orbitDistance;
      moon.position.y = Math.sin(moon.userData.angle) * moon.userData.orbitDistance * 0.5; // Небольшое смещение по оси Y для орбитального наклона
    }
  
    if (currentFocus && !isAnimating) {
      // Если у нас есть текущий фокус и нет анимации, обновляем позицию камеры и цель
      const direction = new THREE.Vector3().subVectors(camera.position, currentFocus.position).normalize();
      const desiredPosition = direction.multiplyScalar(baseDistance).add(currentFocus.position);
      camera.position.copy(desiredPosition);
      controls.target.copy(currentFocus.position);
    }
  
    controls.update();
    renderer.render(scene, camera);
  }
  
animate();
