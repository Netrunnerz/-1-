﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA2._0._1
{
    internal class UserResult
    {
        public int id { get; set; }
        public int mat { get; set; }
        public int phys { get; set; }

        public UserResult() { }

        public UserResult(int mat, int phys)
        {
            this.mat = mat;
            this.phys = phys;
        }
    }
}
