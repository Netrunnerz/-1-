﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LABA2._0._1
{
    
    public partial class AddWindow : Window
    {
        AppContext db;
        public AddWindow()
        {
            InitializeComponent();

            db = new AppContext();
        }

        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void Add2DB_Click(object sender, RoutedEventArgs e)
        {
            string studname = StudName.Text;
            string studgroup = StudGroup.Text;
            int studmat = Convert.ToInt32(StudMat.Text);
            int studphys = Convert.ToInt32(StudPhys.Text);

            UserData userdata = new UserData(studname, studgroup);
            UserResult userResult = new UserResult(studmat, studphys);

            db.UserDatas.Add(userdata);
            db.UserResults.Add(userResult);
            db.SaveChanges();

            MessageBox.Show("Успешно добавленно");

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
