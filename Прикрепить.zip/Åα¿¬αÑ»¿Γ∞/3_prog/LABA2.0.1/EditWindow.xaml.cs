﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LABA2._0._1
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        AppContext db;
        public EditWindow()
        {
            InitializeComponent();

            db = new AppContext();
        }

        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string studname = StudName.Text;
            string studgroup = StudGroup.Text;
            int studmat = Convert.ToInt32(StudMat.Text);
            int studphys = Convert.ToInt32(StudPhys.Text);
            int studid = Convert.ToInt32(Studid.Text);

            UserData userdata = db.UserDatas.Find(studid);
            UserResult userResult = db.UserResults.Find(studid);

            userdata.name = studname;
            userdata.group = studgroup;
            userResult.mat = studmat;
            userResult.phys = studphys;
            db.SaveChanges();

            MessageBox.Show("Успешно обновлено");

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
