﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LABA2._0._1
{
    /// <summary>
    /// Логика взаимодействия для FindWindow.xaml
    /// </summary>
    public partial class FindWindow : Window
    {
        AppContext db;
        UserData userData = new UserData();
        UserResult userResult = new UserResult();
        public FindWindow()
        {
            InitializeComponent();
            
            db = new AppContext();
        }

        private void Find(object sender, RoutedEventArgs e)
        {
            EditWindow editWindow = new EditWindow();
            editWindow.Show();
            
            int id = Convert.ToInt32(StudId.Text);
            userData  = db.UserDatas.Find(id);
            userResult = db.UserResults.Find(id);
            editWindow.Studid.Text = userData.id.ToString();
            editWindow.StudName.Text = userData.name.ToString();
            editWindow.StudGroup.Text = userData.group.ToString();
            editWindow.StudMat.Text = userResult.mat.ToString();
            editWindow.StudPhys.Text = userResult.phys.ToString();

            Close();
        }

        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
