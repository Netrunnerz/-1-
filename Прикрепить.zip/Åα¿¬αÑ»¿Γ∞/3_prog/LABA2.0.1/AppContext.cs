﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace LABA2._0._1
{
    internal class AppContext : DbContext
    {
        public DbSet<UserData> UserDatas { get; set; }
        public DbSet<UserResult> UserResults { get; set; }

        public AppContext() : base("DefaultConnection") { }

    }
}
