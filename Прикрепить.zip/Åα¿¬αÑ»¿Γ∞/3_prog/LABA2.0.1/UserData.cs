﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA2._0._1
{
    internal class UserData
    {
        public int id { get; set; }
        public string name { get; set; }
        public string group { get; set; }

        public UserData() { }

        public UserData(string name, string group)
        {
            this.name = name;
            this.group = group;
        }
    }
}
