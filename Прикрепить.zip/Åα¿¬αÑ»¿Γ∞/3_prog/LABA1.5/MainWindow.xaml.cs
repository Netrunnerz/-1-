﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace LABA1._5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            
            Microsoft.Win32.OpenFileDialog open = new Microsoft.Win32.OpenFileDialog();
            open.FileName = "Document";
            open.DefaultExt = ".txt";
            open.Filter = "Text document (.txt)|*.txt";
            open.ShowDialog();
            using (System.IO.StreamReader reader = new System.IO.StreamReader(open.FileName))
            {
                Text.Text = reader.ReadToEnd();
            }
                
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog save = new Microsoft.Win32.SaveFileDialog();
            save.FileName = "Document";
            save.DefaultExt = ".txt";
            save.Filter = "Text document (.txt)|*.txt";
            save.ShowDialog();
            using (StreamWriter writer = new StreamWriter(save.FileName))
            {
                writer.Write(Text.Text);
            }
        }
    }
}
