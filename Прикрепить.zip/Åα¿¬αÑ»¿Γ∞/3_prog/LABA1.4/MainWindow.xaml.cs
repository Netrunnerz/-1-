﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LABA1._4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DateTime now_datetime = DateTime.Today;
        int year;
        int month;
        int day;
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 1; i < 2024; i++)
            {
                Year.Items.Add(Convert.ToString(i));
            }
            for (int i = 1; i <= 12; i++)
            {
                Mounth.Items.Add(Convert.ToString(i));
            }
            Console.WriteLine(Mounth.SelectedValue + "000000000000");
            int b = Convert.ToInt32(Mounth.SelectedValue);
            b = +1;
            if (b == 1 & b == 3 & b == 5 & b == 7 & b == 8 & b == 10 & b == 11)
            {
                MessageBox.Show("Иди нахуй");
            }



            //DateTime datetime = new DateTime(year, month, day);
        }
        

         
    }
}
