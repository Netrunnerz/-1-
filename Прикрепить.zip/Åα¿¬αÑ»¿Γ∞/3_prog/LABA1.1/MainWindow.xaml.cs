﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LABA1._1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int A;
        int B;
        int res;
        public MainWindow()
        {
            InitializeComponent();

        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            A = Convert.ToInt32(NUM_A.Text);
            B = Convert.ToInt32(NUM_B.Text);
            RES.Text = Convert.ToString(A + B);
        }

        private void Min_Click(object sender, RoutedEventArgs e)
        {
            A = Convert.ToInt32(NUM_A.Text);
            B = Convert.ToInt32(NUM_B.Text);
            RES.Text = Convert.ToString(A - B);
        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            A = Convert.ToInt32(NUM_A.Text);
            B = Convert.ToInt32(NUM_B.Text);
            RES.Text = Convert.ToString(A / B);
        }

        private void Umn_Click(object sender, RoutedEventArgs e)
        {
            A = Convert.ToInt32(NUM_A.Text);
            B = Convert.ToInt32(NUM_B.Text);
            RES.Text = Convert.ToString(A * B);
        }
    }
}
