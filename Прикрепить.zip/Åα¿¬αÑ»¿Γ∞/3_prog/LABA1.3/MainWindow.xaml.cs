﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LABA1._3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            desc.Text = "Меркурий. Самая маленькая из настоящих планет \nСолнечной системы";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            desc.Text = "Венера. Описание ада бралось с неё: страшная \nжара, испарения серы и извержения множества вулканов.";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            desc.Text = "Земля. Третья планета по порядку от Солнца, \nнаш дом.";
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            desc.Text = "Марс. Самая дальняя из планет земной группы \nСолнечной системы. Затем расположен Главный пояс астероидов, где \nнаходятся карликовая планета Церера и малые планеты \nВеста, Паллада и др.";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            desc.Text = "Юпитер. Самая большая планета Солнечной \nсистемы.";
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            desc.Text = "Сатурн со своими знаменитыми кольцами.";
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            desc.Text = "Уран. Самая холодная планета.";
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            desc.Text = "Нептун. Это самая дальняя настоящая планета по \nпорядку от Солнца.";
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            desc.Text = "Плутон. Карликовая планета, которая обычно упоминается \nпосле Нептуна. Но, орбита Плутона такова, что иногда он находится \nближе к Солнцу, чем Нептун.";
        }
    }
}
